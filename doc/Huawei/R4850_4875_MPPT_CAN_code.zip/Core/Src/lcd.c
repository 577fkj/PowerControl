#include "lcd.h"
#include "oledfont.h"


int delay = 1;

void SPI_delay(uint8_t i)
{
//	while(i){
//		GPIOA->BSRR = 0x0080;	//PB7
//		i--;
//	}
}

extern SPI_HandleTypeDef hspi1;


/******************************************************************************
      函数说明：LCD串行数据写入函数
      入口数据：dat  要写入的串行数据
      返回值：  无
******************************************************************************/
void LCD_Writ_Bus(u8 dat) 
{	


}


/******************************************************************************
      函数说明：LCD写入数据
      入口数据：dat 写入的数据
      返回值：  无
******************************************************************************/
void LCD_WR_DATA8(u8 dat)
{
	OLED_DC_Set();//写数据
	OLED_CS_Clr();
	SPI_delay(delay);		//延时

	uint8_t cmd[1] = {dat};
	LCD_SPI_Send(cmd ,1);						
//	HAL_SPI_Transmit(&hspi1, cmd, 1, 0);

	OLED_CS_Set();
	SPI_delay(delay);		//延时
}

 
/******************************************************************************
      函数说明：LCD写入数据
      入口数据：dat 写入的数据
      返回值：  无
******************************************************************************/
void LCD_WR_DATA(u16 dat)
{
	
	OLED_DC_Set();//写数据
	OLED_CS_Clr();
	SPI_delay(delay);		//延时

	uint8_t cmd[2] = {dat>>8,dat};
	LCD_SPI_Send(cmd ,2);
//	HAL_SPI_Transmit(&hspi1, cmd, 2, 0);
	
	OLED_CS_Set();
	SPI_delay(delay);		//延时
}

void LCD_WR_COLOR(u16 dat)
{
	OLED_DC_Set();//写数据
	OLED_CS_Clr();
	SPI_delay(delay);		//延时

	uint8_t cmd[2] = {dat>>8,dat};
	LCD_SPI_Send(cmd ,2);
//	HAL_SPI_Transmit(&hspi1, cmd, 2, 0);
	
	OLED_CS_Set();
	SPI_delay(delay);		//延时
	
}

/******************************************************************************
      函数说明：LCD写入命令
      入口数据：dat 写入的命令
      返回值：  无
******************************************************************************/
void LCD_WR_REG(u8 dat)
{
		
	OLED_DC_Clr();//写命令
	OLED_CS_Clr();
	SPI_delay(delay);		//延时
	
	uint8_t cmd[1] = {dat};
	HAL_SPI_Transmit(&hspi1, cmd, 1, 0);
	
	OLED_CS_Set();
	SPI_delay(delay);		//延时
	
}


/******************************************************************************
      函数说明：设置起始和结束地址
      入口数据：x1,x2 设置列的起始和结束地址
                y1,y2 设置行的起始和结束地址
      返回值：  无
******************************************************************************/
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2)
{
	if(ST7789_7735 == 7789)
	{
		if(USE_HORIZONTAL==0)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+52);
			LCD_WR_DATA(x2+52);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+40);
			LCD_WR_DATA(y2+40);
			LCD_WR_REG(0x2c);//储存器写
		}
		else if(USE_HORIZONTAL==1)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+53);
			LCD_WR_DATA(x2+53);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+40);
			LCD_WR_DATA(y2+40);
			LCD_WR_REG(0x2c);//储存器写
		}
		else if(USE_HORIZONTAL==2)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+40);
			LCD_WR_DATA(x2+40);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+53);
			LCD_WR_DATA(y2+53);
			LCD_WR_REG(0x2c);//储存器写
		}
		else
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+40);
			LCD_WR_DATA(x2+40);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+52);
			LCD_WR_DATA(y2+52);
			LCD_WR_REG(0x2c);//储存器写
		}
	}
	
	if(ST7789_7735 == 7735)
	{
		if(USE_HORIZONTAL==0)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+24);
			LCD_WR_DATA(x2+24);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+0);
			LCD_WR_DATA(y2+0);
			LCD_WR_REG(0x2c);//储存器写
		}
		else if(USE_HORIZONTAL==1)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+24);
			LCD_WR_DATA(x2+24);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+0);
			LCD_WR_DATA(y2+0);
			LCD_WR_REG(0x2c);//储存器写
		}
		else if(USE_HORIZONTAL==2)
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+0);
			LCD_WR_DATA(x2+0);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+24);
			LCD_WR_DATA(y2+24);
			LCD_WR_REG(0x2c);//储存器写
		}
		else
		{
			LCD_WR_REG(0x2a);//列地址设置
			LCD_WR_DATA(x1+0);
			LCD_WR_DATA(x2+0);
			LCD_WR_REG(0x2b);//行地址设置
			LCD_WR_DATA(y1+24);
			LCD_WR_DATA(y2+24);
			LCD_WR_REG(0x2c);//储存器写
		}
	}
}


/******************************************************************************
      函数说明：LCD初始化函数
      入口数据：无
      返回值：  无
******************************************************************************/
void Lcd_Init(void)
{


	OLED_RST_Clr();
	HAL_Delay(120);
	OLED_RST_Set();
	HAL_Delay(120);
	

	if(ST7789_7735 == 7789)
	{
//************* Start Initial Sequence st7789 **********// 		
		LCD_WR_REG(0x11); 	//Sleep Out & Booster On
		HAL_Delay(120); 

		LCD_WR_REG(0x36); 
		if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x00);
		else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC0);
		else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x70);
		else LCD_WR_DATA8(0xA0);

		LCD_WR_REG(0x3A);			//颜色格式
		LCD_WR_DATA8(0x05);			//	03 4 4 4			05 5 6 5 			06 6 6 6

		LCD_WR_REG(0xB2);
		LCD_WR_DATA8(0x0C);
		LCD_WR_DATA8(0x0C);
		LCD_WR_DATA8(0x00);
		LCD_WR_DATA8(0x33);
		LCD_WR_DATA8(0x33); 

		LCD_WR_REG(0xB7); 
		LCD_WR_DATA8(0x35);  

		LCD_WR_REG(0xBB);
		LCD_WR_DATA8(0x19);

		LCD_WR_REG(0xC0);
		LCD_WR_DATA8(0x2C);

		LCD_WR_REG(0xC2);
		LCD_WR_DATA8(0x01);

		LCD_WR_REG(0xC3);
		LCD_WR_DATA8(0x12);   

		LCD_WR_REG(0xC4);
		LCD_WR_DATA8(0x20);  

		LCD_WR_REG(0xC6); 
		LCD_WR_DATA8(0x01);    //帧率 111hz

		LCD_WR_REG(0xD0); 
		LCD_WR_DATA8(0xA4);
		LCD_WR_DATA8(0xA1);

		LCD_WR_REG(0xE0);
		LCD_WR_DATA8(0xD0);
		LCD_WR_DATA8(0x04);
		LCD_WR_DATA8(0x0D);
		LCD_WR_DATA8(0x11);
		LCD_WR_DATA8(0x13);
		LCD_WR_DATA8(0x2B);
		LCD_WR_DATA8(0x3F);
		LCD_WR_DATA8(0x54);
		LCD_WR_DATA8(0x4C);
		LCD_WR_DATA8(0x18);
		LCD_WR_DATA8(0x0D);
		LCD_WR_DATA8(0x0B);
		LCD_WR_DATA8(0x1F);
		LCD_WR_DATA8(0x23);

		LCD_WR_REG(0xE1);
		LCD_WR_DATA8(0xD0);
		LCD_WR_DATA8(0x04);
		LCD_WR_DATA8(0x0C);
		LCD_WR_DATA8(0x11);
		LCD_WR_DATA8(0x13);
		LCD_WR_DATA8(0x2C);
		LCD_WR_DATA8(0x3F);
		LCD_WR_DATA8(0x44);
		LCD_WR_DATA8(0x51);
		LCD_WR_DATA8(0x2F);
		LCD_WR_DATA8(0x1F);
		LCD_WR_DATA8(0x1F);
		LCD_WR_DATA8(0x20);
		LCD_WR_DATA8(0x23);


		LCD_WR_REG(0x20);			//Display Inversion Off (Normal)	反色
		//LCD_WR_REG(0x21);			//Display Inversion On	反色
		LCD_WR_REG(0x11);	//Sleep Out & Booster On
		LCD_WR_REG(0x29); 	//Display On


		OLED_CS_Clr();

		HAL_Delay (1);

		LCD_WR_REG(0x2C);
		
	}else if(ST7789_7735 == 7735)
	{
//************* Start Initial Sequence st7735 !!xianyu!! **********// 		
		LCD_WR_REG(0x11);			//Sleep Out & Booster On
		HAL_Delay(120);				//Delay 120ms
		
		LCD_WR_REG(0xB1);     
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x3C);   
		LCD_WR_DATA8(0x3C);   

		LCD_WR_REG(0xB2);     
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x3C);   
		LCD_WR_DATA8(0x3C);   

		LCD_WR_REG(0xB3);     
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x3C);   
		LCD_WR_DATA8(0x3C);   
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x3C);   
		LCD_WR_DATA8(0x3C);   

		LCD_WR_REG(0xB4);     //Dot inversion
		LCD_WR_DATA8(0x03);   

		LCD_WR_REG(0xC0);     
		LCD_WR_DATA8(0x0E);   
		LCD_WR_DATA8(0x0E);   
		LCD_WR_DATA8(0x04);   

		LCD_WR_REG(0xC1);     
		LCD_WR_DATA8(0xC5);   

		LCD_WR_REG(0xC2);     
		LCD_WR_DATA8(0x0d);   
		LCD_WR_DATA8(0x00);   

		LCD_WR_REG(0xC3);     
		LCD_WR_DATA8(0x8D);   
		LCD_WR_DATA8(0x2A);   

		LCD_WR_REG(0xC4);     
		LCD_WR_DATA8(0x8D);   
		LCD_WR_DATA8(0xEE);   

		LCD_WR_REG(0xC5);     //VCOM
		LCD_WR_DATA8(0x0E); //1D  .06


		LCD_WR_REG(0x36);     //MX, MY, RGB mode
		if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x08);
		else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC8);
		else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x78);
		else LCD_WR_DATA8(0xA8);  

		LCD_WR_REG(0x3A); 		//颜色格式 16bit
		LCD_WR_DATA8(0x05);		//	03 4 4 4			05 5 6 5 			06 6 6 6
			
		LCD_WR_REG(0xE0);     
		LCD_WR_DATA8(0x0b);   
		LCD_WR_DATA8(0x17);   
		LCD_WR_DATA8(0x0a);   
		LCD_WR_DATA8(0x0d);   
		LCD_WR_DATA8(0x1a);   
		LCD_WR_DATA8(0x19);   
		LCD_WR_DATA8(0x16);   
		LCD_WR_DATA8(0x1d);   
		LCD_WR_DATA8(0x21);   
		LCD_WR_DATA8(0x26);   
		LCD_WR_DATA8(0x37);   
		LCD_WR_DATA8(0x3c);   
		LCD_WR_DATA8(0x00);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x10);   

		LCD_WR_REG(0xE1);     
		LCD_WR_DATA8(0x0c);   
		LCD_WR_DATA8(0x19);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x0d);   
		LCD_WR_DATA8(0x1b);   
		LCD_WR_DATA8(0x19);   
		LCD_WR_DATA8(0x15);   
		LCD_WR_DATA8(0x1d);   
		LCD_WR_DATA8(0x21);   
		LCD_WR_DATA8(0x26);   
		LCD_WR_DATA8(0x39);   
		LCD_WR_DATA8(0x3E);   
		LCD_WR_DATA8(0x00);   
		LCD_WR_DATA8(0x09);   
		LCD_WR_DATA8(0x05);   
		LCD_WR_DATA8(0x10);   
		 
		HAL_Delay(120);

		//LCD_WR_REG(0x20);			//Display Inversion Off (Normal)	反色
		//LCD_WR_REG(0x21);			//Display Inversion On	反色

		LCD_WR_REG(0x11); 	//Display Inversion On
		LCD_WR_REG(0x29); 	//Display On

	}
} 


/******************************************************************************
      函数说明：LCD清屏函数
      入口数据：无
      返回值：  无
******************************************************************************/
void LCD_Clear(u16 Color)
{
	u16 i ;  	
	LCD_Address_Set(0,0,LCD_W - 1,LCD_H - 1);
	
	OLED_DC_Set();//写数据
	OLED_CS_Clr();
	SPI_delay(delay);		//延时
	
	uint8_t cmd[16] = {Color >> 8,Color,Color >> 8,Color,Color >> 8,Color,Color >> 8,Color,Color >> 8,Color,Color >> 8,Color,Color >> 8,Color,Color >> 8,Color} ;

    for(i=0;i<((LCD_W * LCD_H) / 8) ;i++)
	{
//		HAL_SPI_Transmit(&hspi1,cmd,16, 0); 					//八个像素 一个像素两字节(16bit)		进出25us(stm32g431_16M ,spi_8M)
		LCD_SPI_Send(cmd ,16);
	}
	
	OLED_CS_Set();
	SPI_delay(delay);		//延时
	

//		HAL_SPI_TransmitReceive(&hspi1,cmd,&Rxdata,2, 0);		//一个像素		进出11us(stm32g431_16M ,spi_8M)

}


/******************************************************************************
      函数说明：LCD显示汉字
	  阴码 逐行 逆向 行像素8倍数
	  
      入口数据：x,y   起始坐标
                index 汉字的序号
                size  字号
      返回值：  无
******************************************************************************/
//void LCD_ShowChinese(u16 x,u16 y,u8 num,u8 size)
//{
//	uint8_t cmd[16] = {0} ;
//
//	u8 temp,pos,t;
////	u16 x0=x;
//	u8 csize=size*size/8;	//得到字体一个字符对应点阵集所占的字节数
//
//	LCD_Address_Set(x,y,x+size-1,y+size-1);      //设置光标位置
//
//		for(pos=0;pos<csize;pos++)
//		{
//			if(size==16)temp=Hzk16[num - 1][pos];
//			else if(size==24)temp=Hzk24[num - 1][pos];
//			else return;
//			for(t=0;t<8;t++)
//			{
//				if(temp&0x01){
//					cmd[t * 2] = COLOR >> 8 ;					//点亮
//					cmd[(t * 2) + 1] = COLOR & 0xff ;
//
//				}else{
//					cmd[t * 2] = BACK_COLOR >> 8;				//不点亮
//					cmd[(t * 2) + 1] = BACK_COLOR  & 0xff;
//					}
//					temp>>=1;
////					x++;
//			}
////			x=x0;
////			y++;
//			OLED_DC_Set();//写数据
//			OLED_CS_Clr();
//			SPI_delay(delay);		//延时
//			LCD_SPI_Send(cmd ,16);								//硬件spi发送数据
//			OLED_CS_Set();
//			SPI_delay(delay);		//延时
//		}
//
//}


/******************************************************************************
      函数说明：LCD画点
      入口数据：x,y   起始坐标
      返回值：  无
******************************************************************************/
void LCD_DrawPoint(u16 x,u16 y,u16 color)
{
	LCD_Address_Set(x,y,x,y);//设置光标位置 
	LCD_WR_COLOR(color);
} 


/******************************************************************************
      函数说明：LCD画一个大的点
      入口数据：x,y   起始坐标
      返回值：  无
******************************************************************************/
void LCD_DrawPoint_big(u16 x,u16 y,u16 color)
{
	LCD_Fill(x-1,y-1,x+1,y+1,color);
} 


/******************************************************************************
      函数说明：在指定区域填充颜色
      入口数据：xsta,ysta   起始坐标
                xend,yend   终止坐标
      返回值：  无
******************************************************************************/
void LCD_Fill(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color)
{          
	u16 i,j; 
	LCD_Address_Set(xsta,ysta,xend,yend);      //设置光标位置 
	for(i=ysta;i<=yend;i++)
	{													   	 	
		for(j=xsta;j<=xend;j++)LCD_WR_COLOR(color);//设置光标位置 	    
	} 					  	    
}


/******************************************************************************
      函数说明：画线
      入口数据：x1,y1   起始坐标
                x2,y2   终止坐标
      返回值：  无
******************************************************************************/
void LCD_DrawLine(u16 x1,u16 y1,u16 x2,u16 y2,u16 color)
{
	u16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance;
	int incx,incy,uRow,uCol;
	delta_x=x2-x1; //计算坐标增量 
	delta_y=y2-y1;
	uRow=x1;//画线起点坐标
	uCol=y1;
	if(delta_x>0)incx=1; //设置单步方向 
	else if (delta_x==0)incx=0;//垂直线 
	else {incx=-1;delta_x=-delta_x;}
	if(delta_y>0)incy=1;
	else if (delta_y==0)incy=0;//水平线 
	else {incy=-1;delta_y=-delta_x;}
	if(delta_x>delta_y)distance=delta_x; //选取基本增量坐标轴 
	else distance=delta_y;
	for(t=0;t<distance+1;t++)
	{
		LCD_DrawPoint(uRow,uCol,color);//画点
		xerr+=delta_x;
		yerr+=delta_y;
		if(xerr>distance)
		{
			xerr-=distance;
			uRow+=incx;
		}
		if(yerr>distance)
		{
			yerr-=distance;
			uCol+=incy;
		}
	}
}


/******************************************************************************
      函数说明：画矩形
      入口数据：x1,y1   起始坐标
                x2,y2   终止坐标
      返回值：  无
******************************************************************************/
void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2,u16 color)
{
	LCD_DrawLine(x1,y1,x2,y1,color);
	LCD_DrawLine(x1,y1,x1,y2,color);
	LCD_DrawLine(x1,y2,x2,y2,color);
	LCD_DrawLine(x2,y1,x2,y2,color);
}


/******************************************************************************
      函数说明：画圆
      入口数据：x0,y0   圆心坐标
                r       半径
      返回值：  无
******************************************************************************/
void Draw_Circle(u16 x0,u16 y0,u8 r,u16 color)
{
	int a,b;
	a=0;b=r;	  
	while(a<=b)
	{
		LCD_DrawPoint(x0-b,y0-a,color);             //3           
		LCD_DrawPoint(x0+b,y0-a,color);             //0           
		LCD_DrawPoint(x0-a,y0+b,color);             //1                
		LCD_DrawPoint(x0-a,y0-b,color);             //2             
		LCD_DrawPoint(x0+b,y0+a,color);             //4               
		LCD_DrawPoint(x0+a,y0-b,color);             //5
		LCD_DrawPoint(x0+a,y0+b,color);             //6 
		LCD_DrawPoint(x0-b,y0+a,color);             //7
		a++;
		if((a*a+b*b)>(r*r))//判断要画的点是否过远
		{
			b--;
		}
	}
}



//m^n函数
//返回值:m^n次方.
u32 LCD_Pow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}


/******************************************************************************
      函数说明：LCD显示字符
	  阴码 逐行 逆向 行像素8倍数

      入口数据：x,y   起始坐标

                size  字号
      返回值：  无
******************************************************************************/
void LCD_ShowChar(u16 x,u16 y,u8 num,u8 size)
{
	uint8_t cmd[16] = {0} ;

	u8 temp,pos,t;
//	u16 x0=x;
	if(x>LCD_W-size||y>LCD_H-size)return;
	u8 csize=(size/8+((size%8)?1:0))*(size/2);

	LCD_Address_Set(x,y,x+(size/2)-1,y+size-1);      //设置光标位置

		for(pos=0;pos<csize;pos++)
		{
			if(size==16)temp=asc2_1608[num][pos];
//			else if(size==48)temp=asc2_4824[num][pos];	//调用2412字体
			else return;
			for(t=0;t<8;t++)
			{
				if(temp&0x01){
					cmd[t * 2] = COLOR >> 8 ;					//点亮
					cmd[(t * 2) + 1] = COLOR & 0xff ;

				}else{
					cmd[t * 2] = BACK_COLOR >> 8;				//不点亮
					cmd[(t * 2) + 1] = BACK_COLOR  & 0xff;
					}
					temp>>=1;
//					x++;
			}
//			x=x0;
//			y++;
			OLED_DC_Set();//写数据
			OLED_CS_Clr();
			SPI_delay(delay);		//延时
			LCD_SPI_Send(cmd ,16);								//硬件spi发送数据
			OLED_CS_Set();
			SPI_delay(delay);		//延时
		}

}

//在指定位置显示一个字符
//x,y:起始坐标
//num:要显示的字符:" "--->"~"
//size:字体大小 12/16/24/32
//mode:叠加方式(1)还是非叠加方式(0)
//PC2LCD2002取模方式设置：阴码+逐列式+顺向+C51格式
void LCD_ShowChar2(u16 x,u16 y,u8 num,u8 size)
{  							  
    u8 temp,t1,t;
	u16 y0=y;
	u8 csize=(size/8+((size%8)?1:0))*(size/2);		//得到字体一个字符对应点阵集所占的字节数	
 	num=num-' ';//得到偏移后的值（ASCII字库是从空格开始取模，所以-' '就是对应字符的字库）
	

	uint8_t cmd[16] = {0} ;
						
						
	for(t=0;t<csize;t++)
	{   
		if(size==16)temp=asc2_1608[num][t];
		else if(size==24)temp=asc2_2412[num][t];	//调用2412字体

		else return;								//没有的字库
		
		int y7 = y + 7;
		if( y7 > ( y0 + size ) ) y7 = ( y0 + size ) ;
		LCD_Address_Set( x, y, x, y7 ) ;				//设置显示区域(垂直八个点)
		
		for(t1=0;t1<8;t1++)								//画八个点(一字节)
		{			    

			if(temp&0x80)
			{
				cmd[t1 * 2] = COLOR >> 8 ;					//点亮
				cmd[(t1 * 2) + 1] = COLOR & 0xff ;
			}else
			{
				cmd[t1 * 2] = BACK_COLOR >> 8;				//不点亮
				cmd[(t1 * 2) + 1] = BACK_COLOR  & 0xff;
			}
			temp<<=1;
			y++;
			if((y-y0)==size)
			{
				y=y0;
				x++;
				break;
			}
		}  	
		OLED_DC_Set();//写数据
		OLED_CS_Clr();
		SPI_delay(delay);		//延时
		LCD_SPI_Send(cmd ,16);								//硬件spi发送数据
		OLED_CS_Set();	
		SPI_delay(delay);		//延时

	}  	    	   	 	  
}   


//显示字符串
//x,y:起点坐标
//width,height:区域大小  
//size:字体大小
//*p:字符串起始地址		  
void LCD_ShowString2(u16 x,u16 y,u16 width,u16 height,u8 size,char *p)
{         
	u8 x0=x;
	width+=x;
	height+=y;
	while((*p<='~')&&(*p>=' '))//判断是不是非法字符!
    {       
    	if(x>=width){x=x0;y+=size;}
        if(y>=height)break;//退出
		LCD_ShowChar2(x,y,*p,size);
		x+=size/2;
		p++;
	}
}


/******************************************************************************
      函数说明：显示数字
      入口数据：m底数，n指数
      返回值：  无
******************************************************************************/
u32 mypow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}



//显示数字,高位为0,则不显示
//x,y :起点坐标	 
//len :数字的位数
//size:字体大小
//color:颜色 
//num:数值(0~4294967295);	 
//mode: 1 不填零		0 填零
void LCD_ShowNum2(u16 x,u16 y,u32 num,u8 len,u8 size,u8 mode)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(mode){
				if(temp==0)
				{
					LCD_ShowChar2(x+(size/2)*t,y,' ',size);
					continue;
				}else enshow=1; 
			}else{
				if(temp==0)
				{
					LCD_ShowChar2(x+(size/2)*t,y,'0',size);
					continue;
				}else enshow=1; 
			}
			
		 	 
		}
	 	LCD_ShowChar2(x+(size/2)*t,y,temp+'0',size);
	}
} 


/******************************************************************************
      函数说明：显示40x40图片
      入口数据：x,y    起点坐标
      返回值：  无
******************************************************************************/
//void LCD_ShowPicture(u16 x1,u16 y1,u16 x2,u16 y2)
//{
//	int i;
//	  LCD_Address_Set(x1,y1,x2,y2);
//		for(i=0;i<1600;i++)
//	  { 	
//			LCD_WR_DATA8(image[i*2+1]);	 
//			LCD_WR_DATA8(image[i*2]);			
//	  }			
//}



/******************************************************************************

******************************************************************************/
void LCD_SPI_Send(uint8_t *data, uint16_t size)
{
    for(int i = 0 ; i < size ; i++)
    {
        *((uint8_t*)&hspi1.Instance->DR) = data[i];

        while(__HAL_SPI_GET_FLAG(&hspi1, SPI_FLAG_TXE) != 1) {}
    }
}











