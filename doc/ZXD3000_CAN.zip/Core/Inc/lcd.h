#ifndef __OLED_H
#define __OLED_H	   						  

#include "main.h"
#include "stdlib.h"	  

#define USE_HORIZONTAL 3  //设置横屏或者竖屏显示 0或1为竖屏 2或3为横屏
#define	ST7789_7735 7735


#define BACK_COLOR		0
#define COLOR			0xFFFF


#if ST7789_7735 == 7789
#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 135
#define LCD_H 240

#else
#define LCD_W 240
#define LCD_H 135
#endif
#endif

#if ST7789_7735 == 7735
#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 80
#define LCD_H 160

#else
#define LCD_W 160
#define LCD_H 80
#endif
#endif

#define	u8 unsigned char
#define	u16 unsigned int
#define	u32 unsigned long




//-----------------OLED端口定义---------------- 
#define OLED_DC_Clr()	HAL_GPIO_WritePin(LCD_D_C_GPIO_Port,LCD_D_C_Pin, GPIO_PIN_RESET)
#define OLED_DC_Set()	HAL_GPIO_WritePin(LCD_D_C_GPIO_Port,LCD_D_C_Pin, GPIO_PIN_SET)

#define OLED_RST_Clr()	HAL_GPIO_WritePin(LCD_RST_GPIO_Port,LCD_RST_Pin, GPIO_PIN_RESET)//RES
#define OLED_RST_Set()	HAL_GPIO_WritePin(LCD_RST_GPIO_Port,LCD_RST_Pin, GPIO_PIN_SET)
 		     
#define OLED_CS_Clr()	HAL_GPIO_WritePin(LCD_CS_GPIO_Port,LCD_CS_Pin, GPIO_PIN_RESET)
#define OLED_CS_Set()	HAL_GPIO_WritePin(LCD_CS_GPIO_Port,LCD_CS_Pin, GPIO_PIN_SET)



void LCD_Writ_Bus(u8 dat);
void LCD_WR_DATA8(u8 dat);
void LCD_WR_DATA(u16 dat);
void LCD_WR_REG(u8 dat);
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);
void Lcd_Init(void); 
void LCD_Clear(u16 Color);
//void LCD_ShowChinese(u16 x,u16 y,u8 num,u8 size);
void LCD_DrawPoint(u16 x,u16 y,u16 color);
void LCD_DrawPoint_big(u16 x,u16 y,u16 colory);
void LCD_Fill(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color);
void LCD_DrawLine(u16 x1,u16 y1,u16 x2,u16 y2,u16 color);
void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2,u16 color);
void Draw_Circle(u16 x0,u16 y0,u8 r,u16 color);



u32 mypow(u8 m,u8 n);
void LCD_ShowNum(u16 x,u16 y,u16 num,u8 len,u32 color);

void LCD_ShowNum1(u16 x,u16 y,float num,u8 len,u32 color);
void LCD_ShowPicture(u16 x1,u16 y1,u16 x2,u16 y2);

void LCD_ShowChar(u16 x,u16 y,u8 num,u8 size);
void LCD_ShowChar2(u16 x,u16 y,u8 num,u8 size);
//void LCD_ShowChar3(u16 x,u16 y,u8 num);
void LCD_ShowString2(u16 x,u16 y,u16 width,u16 height,u8 size,char *p);
void LCD_ShowNum2(u16 x,u16 y,u32 num,u8 len,u8 size,u8 mode);	

void LCD_SPI_Send(uint8_t *data, uint16_t size);

//画笔颜色
#define WHITE         	 0xffffff
#define BLACK         	 0x0000	  

					  		 
#endif   		     








