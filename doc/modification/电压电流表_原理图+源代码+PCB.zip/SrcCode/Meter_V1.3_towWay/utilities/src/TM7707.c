#include "STC15.h"
#include "TM7707.h"
#include "delay.h"

#define READ_CH1_DATA		0x38
#define READ_CH2_DATA		0x39

#define TM_SCLK		P55
#define TM_MCLKI	P54
#define TM_CS		P15
#define TM_RESET	P14
#define TM_DRDY		P11
#define TM_DOUT		P10
#define TM_DIN		P37




static void TM_WriteByte(const unsigned char dat);
static unsigned char TM_ReadByte(void);

unsigned long raw_adcV=0, raw_adcI=0;

/***************************************************
 *
 */
static void TM_WriteByte(const unsigned char dat)
{
	unsigned char pos=0;
	unsigned char t_dat = dat;
	
	TM_CS = 0;
	TM_SCLK = 1;
	_nop_(); _nop_();
	for(pos=0; pos<8; pos++)
	{
		TM_SCLK = 0;
		_nop_();
		TM_DIN = (t_dat&0x80)?1:0;
		TM_SCLK = 1;
		_nop_();
		t_dat <<= 1;
	}
	TM_CS = 1;
}

/***************************************************
 *
 */
static unsigned char TM_ReadByte(void)
{
	unsigned char pos=0;
	unsigned char raw=0;
	
	TM_CS = 0;
	TM_SCLK = 1;
	_nop_(); _nop_();
	for(pos=0; pos<8; pos++)
	{
		TM_SCLK = 0;
		_nop_();
		raw = (raw<<1)|TM_DOUT;
		TM_SCLK = 1;
		_nop_();
	}
	TM_CS = 1;
	return raw;
}

/***************************************************
 *
 */
void GetCurrent(void)
{	
	while(TM_DRDY) { _nop_(); }
	TM_WriteByte(0x10);
	TM_WriteByte(0x04);
	TM_WriteByte(READ_CH1_DATA);
	
	raw_adcI = TM_ReadByte();
	raw_adcI <<= 8;
	raw_adcI |= TM_ReadByte();
	
	#if (defined USE_TM7707)
	raw_adcI <<= 8;
	raw_adcI |= TM_ReadByte();
	#endif
}

void GetVolgate(void)
{	
	while(TM_DRDY) { _nop_(); }
	TM_WriteByte(0x11);
	TM_WriteByte(0x28);
	TM_WriteByte(READ_CH2_DATA);
	
	raw_adcV = TM_ReadByte();
	raw_adcV <<= 8;
	raw_adcV |= TM_ReadByte();
	
	#if (defined USE_TM7707)
	raw_adcV <<= 8;
	raw_adcV |= TM_ReadByte();
	#endif
}



/***************************************************
 *
 *
 *
 */
void TM770x_Config(void)
{
	CLK_DIV = 0xC0;	//P54=SYSCLK/4
	
	TM_RESET = 0;
	delay_ms(10);
	TM_RESET = 1;
	
	TM_DOUT = 1;
	TM_DIN = 1;
	TM_SCLK = 1;
	TM_CS = 1;
	TM_DRDY = 1;
	delay_ms(5);
	
	#if (defined USE_TM7707)
	
	TM_WriteByte(0x40);
	TM_WriteByte(0x01);
	delay_ms(10);
	
	
	/* ͨ��1 */
	//�˲����Ͱ�λ
	TM_WriteByte(0x50);
	TM_WriteByte(0x00);
	//�˲����߰�λ
	TM_WriteByte(0x20);
	TM_WriteByte(0x16);
	
	//��У׼
	TM_WriteByte(0x10);
	TM_WriteByte(0x44);
	while(TM_DRDY) { _nop_(); }
	
	/* ͨ��2 */
	//�˲����Ͱ�λ
	TM_WriteByte(0x51);
	TM_WriteByte(0x00);
	//�˲����߰�λ
	TM_WriteByte(0x22);
	TM_WriteByte(0x36);
	
	//��У׼
	TM_WriteByte(0x11);
	TM_WriteByte(0x68);
	while(TM_DRDY) { _nop_(); }

	#elif (defined USE_TM7705)
	
	/* ͨ��1 */
	//ʱ��
	TM_WriteByte(0x20);
	TM_WriteByte(0x15);
	
	//��У׼
	TM_WriteByte(0x11);
	TM_WriteByte(0x44);
	while(TM_DRDY) { _nop_(); }
	
	//��У׼
	TM_WriteByte(0x10);
	TM_WriteByte(0x6C);
	while(TM_DRDY) { _nop_(); }
	#endif
	
	
}

















