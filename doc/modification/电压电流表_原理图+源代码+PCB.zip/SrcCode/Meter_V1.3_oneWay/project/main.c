#include "stc15.h"
#include "delay.h"
#include "timer.h"
#include "TM7707.h"
#include "LCD1602.h"
#include "eeprom.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#if (defined USE_TM7707)
#define TM_ADC_TO_VOLGATE	1.49056e-4 //
#define TM_ADC_TO_CURRENT	2.98023e-4
#elif (defined USE_TM7705)
#define TM_ADC_TO_VOLGATE	3.81469e-2
#define TM_ADC_TO_CURRENT	3.81469e-2
#endif
#define TM_VOLGATE_RATIO	25
#define TM_REAL_VOLGATE		(TM_ADC_TO_VOLGATE*TM_VOLGATE_RATIO)
#define TM_REAL_CURRENT		(TM_ADC_TO_CURRENT)


static void System_Config(void);
static void ChoiceMode(void);
static unsigned char KeyScan(void);


unsigned char code releaseKey[15] = "Release key    ";
unsigned char code input0A[15] = "Input 0.000A   ";
unsigned char code input5V[15] = "Input 5.000V   ";
unsigned char code input3A[15] = "Input 3.000A   ";
unsigned char code calibFinish[15] = "Finish         ";
unsigned char code V_UP[2] = "V+";
unsigned char code V_DOWN[2] = "V-";
unsigned char code I_UP[2] = "A+";
unsigned char code I_DOWN[2] = "A-";

xdata float v_ratio=1.0f;
xdata float i_ratio=1.0f;
xdata long volgate=0;
xdata long current=0, i_offset=0;
xdata long power=0;
xdata long ohm=0;
xdata long AH=0;
xdata unsigned int timer_cnt=0;
xdata unsigned char dis_cnt=0;
xdata unsigned char sec=0;
xdata unsigned char min=0;
xdata unsigned char hour=0;
unsigned long sec_sum=0;
float ah_sec=0;
float ah_sum=0;
xdata unsigned char mode_flag=1;

xdata long mTemp=0;

bit isDisFlag=1;
bit isDisAhStop=1;
bit isUpdataAH = 0;

/***************************************************
 *
 *
 *
 */
void main(void)
{
	unsigned char keyCode=0;
	
	System_Config();
	LCD1602_Config();
	Timer_Config();
	TM770x_Config();
	EA = 1;
	ChoiceMode();
	EA = 0;
	mode_flag = IapReadByte(EEPROM_MODE_ADDR);
	IapReadData(EEPROM_V_RATIO_ADDR, (long*)&volgate);
	IapReadData(EEPROM_I_RATIO_ADDR, (long*)&current);
	IapReadData(EEPROM_I_ZERO_ADDR, (long*)&i_offset);
	EA = 1;
	v_ratio = volgate*1e-5;
	i_ratio = current*1e-5;
	if(mode_flag!=2 && mode_flag!=1)
	{
		mode_flag = 1;
		IapSaveData(EEPROM_MODE_ADDR, (unsigned char*)&mode_flag, 1);
	}
	
	volgate = 0;
	current = 0;
	AH = 0;

	LCD1602_Write(LCD_WR_CMD, 0x01);
	delay_ms(10);
	
//	volgate = 123456;
//	DisplayNumber(0,0, volgate, 0xFF);
//	DisplayTimer(hour,min,sec);
//	while(1);
//	mode_flag = 1;
	
	for(;;)
	{
		keyCode = KeyScan();
		if(keyCode==0)
		{
			if(mode_flag==2)
			{
				hour = 0;
				min = 0;
				sec = 0;
				AH = 0;
				ah_sum = 0;
				sec_sum = 0;
				isDisAhStop = 1;
			}
		}
		else if(keyCode!=0xFF)
		{
			if(mode_flag==2)
			{
				isDisAhStop = ~isDisAhStop;
			}
		}
		
		if(isDisFlag)
		{
			isDisFlag = 0;
			if(P36 && (mode_flag==1))
			{
				DisplayNumber(0,0, volgate, DIS_V);
				DisplayNumber(0,1, power, 	DIS_W);
				DisplayNumber(9,0, current, DIS_A);
				DisplayNumber(9,1, ohm, 	DIS_R);
			}
			else if(mode_flag==2)
			{
				if(isDisAhStop==0 && isUpdataAH)
				{
					isUpdataAH = 0;
					ah_sec = 2.77778e-4*current;
					ah_sum += ah_sec;
				}
				AH = (long)ah_sum;
				DisplayNumber(0,0, volgate, DIS_V);
				DisplayNumber(0,1, current, DIS_A);
				DisplayNumber(8, 0, AH, DIS_AH);
				DisplayTimer(hour,min,sec);
			}
			
			GetVolgate();
			mTemp = (long)(raw_adcV*TM_REAL_VOLGATE*v_ratio);
			if(mTemp>=20000)
			{
				volgate =  (long)(0.9976f*mTemp + 40);
			}
			else
			{
				volgate = mTemp;
			}
			GetCurrent();
//			current = (long)((raw_adcI*TM_REAL_CURRENT-i_offset)*i_ratio-i_offset);
			if(raw_adcI>=i_offset)
			{ current = (long)((raw_adcI-i_offset)*TM_REAL_CURRENT*i_ratio); }
			else { current = 0; }
			
			if(volgate<0) { volgate = 0; }
			if(current<0) { current = 0;}//-current; }
			if(current>5)
			{
				power = volgate * current / 1000;
				ohm = 1000 * volgate / (current+1);
			}
			else
			{
				power = 0;
				ohm = 0;
			}
		}
		
	}
}




/***************************************************
 *
 */
static void System_Config(void)
{
	P1M1 = (0<<0)|(0<<1)|(0<<2)|(0<<3)|(0<<4)|(0<<5);
	P1M0 = (0<<0)|(0<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5);
	
	P3M1 = (0<<0)|(0<<1)|(0<<2)|(0<<3)|(0<<6)|(0<<7);
	P3M0 = (0<<0)|(0<<1)|(1<<2)|(1<<3)|(0<<6)|(1<<7);
	
	P5M1 = (0<<4)|(0<<5);
	P5M0 = (0<<4)|(1<<5);
	
	P36 = 1;
}

/***************************************************
 *
 */
void tm0_isr() interrupt 1 using 1
{
	if(isDisAhStop==0)
	{
		timer_cnt++;
	}
	
	dis_cnt++;
	if(timer_cnt>=500)
	{
		if(mode_flag==2)
		{
			isUpdataAH = 1;
		}
		sec++;
		sec_sum++;
		if(sec_sum>=360000)
		{
			sec_sum = 360000;
		}
		if(sec>=60)
		{
			sec = 0;
			min++;
			if(min>=60)
			{
				min = 0;
				hour++;
				if(hour>99)
				{
					hour = 99;
				}
			}
		}
		timer_cnt = 0;
	}
	
	if(dis_cnt>=150)
	{
		dis_cnt = 0;
		isDisFlag = 1;
	}
}


/***************************************************
 *
 */
static unsigned char KeyScan(void)
{
	static bit isLockKey=1;
	unsigned char key_cnt=120;

	if(!P36 && isLockKey)
	{
		isLockKey = 0;
		do
		{
			key_cnt--;
			delay_ms(10);
		}while(!P36 && key_cnt>0);
		return key_cnt;
	}
	else if(P36)
	{
		isLockKey = 1;
	}
	
	return 0xFF;
}

/***************************************************
 *
 */
static void ChoiceMode(void)
{
	long temp=0;
	long vTemp;
	unsigned char keyCode=0;
	unsigned char key_flag=1;
	unsigned char type_char0=0,type_char1=0;
	float zero=0;
	long itemp=0;
	
	if(!P36)
	{
		LCD1602_WriteString(0, 0, releaseKey, 15);
		while(!P36) { ; }
		LCD1602_WriteString(0, 0, "MODE 1     ", 11);
		LCD1602_WriteString(9, 1, "Ver1.30", 7);
		
		while(1)
		{
			keyCode = KeyScan();
			if(keyCode==0)	
			{
				break;
			}
			else if(keyCode!=0xFF) //�̰�
			{
				mode_flag = (mode_flag>=4)?1:mode_flag+1;
				LCD1602_WriteChar(5,0, mode_flag+'0');
			}
		}
		
		if(mode_flag<=2 && mode_flag>0)
		{
			IapSaveData(EEPROM_MODE_ADDR, (unsigned char*)&mode_flag, 1);
		}
		
		if(mode_flag==3)
		{
			type_char0 = 'V';
			type_char1 = '+';
			temp = v_ratio*1e5;
			LCD1602_WriteChar(1,1, type_char0);
			LCD1602_WriteChar(2,1, type_char1);
			DisplayNumber(9,1, temp, 0xFF);
			while(1)
			{
//				if(isDisFlag)
				{
//					isDisFlag = 0;
					GetVolgate();
					volgate = (long)(raw_adcV*TM_REAL_VOLGATE*v_ratio);
					GetCurrent();
					current = (long)((raw_adcI-i_offset)*TM_REAL_CURRENT*i_ratio);
					DisplayNumber(0,0, volgate, DIS_V);
					DisplayNumber(9,0, current, DIS_A);
				}

				keyCode = KeyScan();
				if(keyCode==0)	
				{
					key_flag++;
					if(key_flag==2) 
					{ 
						type_char1 = '-';
					}
					else if(key_flag==3) 
					{
						vTemp = temp;
						temp = i_ratio*1e5; 
						type_char0 = 'A'; 
						type_char1 = '+'; 
					}
					else if(key_flag==4) 
					{
						type_char1 = '-'; 
					}
					else 
					{ 
						v_ratio = vTemp * 1e-5;
						i_ratio = temp * 1e-5;
						IapSaveData(EEPROM_V_RATIO_ADDR, (unsigned char*)&vTemp, 4);
						IapSaveData(EEPROM_I_RATIO_ADDR, (unsigned char*)&temp, 4);
						break; 
					}
					LCD1602_WriteChar(1,1, type_char0);
					LCD1602_WriteChar(2,1, type_char1);
					DisplayNumber(9,1, temp, 0xFF);
				}
				else if(keyCode!=0xFF) //�̰�
				{
					if(key_flag==1) { temp++; }
					else if(key_flag==2) { temp--; }
					else if(key_flag==3) { temp+=4; }
					else if(key_flag==4) { temp-=4; }
					DisplayNumber(9,1, temp, 0xFF);
				}
			}
		}
		else if(mode_flag==4)
		{
			LCD1602_Write(LCD_WR_CMD, 0x01);
			delay_ms(10);
			LCD1602_WriteString(0, 0, releaseKey, 15);
			while(!P36) { ; }
			LCD1602_WriteString(0, 0, input0A, 15);
			i_offset = 0;
			
			while(1)
			{
				if(isDisFlag)
				{
					isDisFlag = 0;
					GetVolgate();
					volgate = (long)(raw_adcV*TM_REAL_VOLGATE);
					GetCurrent();
					if(key_flag==1) 
					{ 
						zero = raw_adcI*0.3 +0.7*zero;
						current = (long)zero;
						if(current>itemp) { itemp = current; }
					}
					else { current = (long)((raw_adcI-i_offset)*TM_REAL_CURRENT); }
					if(key_flag==2) { temp = volgate; }
					else if(key_flag==1) { temp = itemp; }
					else{ temp = current; }
					DisplayNumber(9,1, temp, 0xFF);
				}

				keyCode = KeyScan();
				if(keyCode!=0xFF)
				{
					key_flag++;
					if(key_flag==2) 
					{ 
						i_offset = itemp;
						IapSaveData(EEPROM_I_ZERO_ADDR, (unsigned char*)&i_offset, 4);
						LCD1602_WriteString(0, 0, input5V, 15); 
					}
					else if(key_flag==3) 
					{ 
						temp = (long)(5e+8 / volgate);
						IapSaveData(EEPROM_V_RATIO_ADDR, (unsigned char*)&temp, 4);
						LCD1602_WriteString(0, 0, input3A, 15); 
					}
					else 
					{ 
						temp = (long)(3e+8 / current);
						IapSaveData(EEPROM_I_RATIO_ADDR, (unsigned char*)&temp, 4);
						break; 
					}
				}
			}
		}
		LCD1602_Write(LCD_WR_CMD, 0x01);
		delay_ms(10);
		LCD1602_WriteString(0, 0, calibFinish, 15);
		delay_ms(500);
	}
}











