#ifndef __CONFIG_VAR_H_
#define __CONFIG_VAR_H_


extern long AH;
extern unsigned char sec;
extern unsigned char min;
extern unsigned char hour;


#endif
