#ifndef __LCD1602_H_
#define __LCD1602_H_


#define LCD_WR_CMD			0
#define LCD_WR_DATA			1

#define DIS_V				'V'
#define DIS_A				'A'
#define DIS_W				'W'
#define DIS_R				0x00
#define DIS_AH				'H'
#define DIS_TIME			'T'


void LCD1602_Config(void);
void LCD1602_Write(unsigned char type, unsigned char res);

//void LCD1602_SetXY(unsigned char x, unsigned char y);
void LCD1602_WriteChar(unsigned char x, unsigned char y, unsigned char chr);
void LCD1602_WriteString(unsigned char x, unsigned char y, unsigned char *chr, unsigned char len);

void DisplayNumber(unsigned char x, unsigned char y, long num, unsigned char type);
void DisplayTimer(unsigned char h, unsigned char m, unsigned char s);

#endif

