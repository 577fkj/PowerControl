#ifndef __TIMER_H
#define __TIMER_H

#define T0MS		(65536 - SYSCLK / 500)      //12T

void Timer_Config(void);

#endif
