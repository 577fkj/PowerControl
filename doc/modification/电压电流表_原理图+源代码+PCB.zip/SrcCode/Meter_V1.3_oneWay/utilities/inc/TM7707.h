#ifndef __TM7707_H_
#define __TM7707_H_

#define ADCV		'V'
#define ADCI		'I'

extern unsigned long raw_adcV, raw_adcI;

void TM770x_Config(void);
void GetVolgate(void);
void GetCurrent(void);

#endif

