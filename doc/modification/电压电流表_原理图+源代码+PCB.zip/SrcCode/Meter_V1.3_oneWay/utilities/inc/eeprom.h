#ifndef __EEPROM_H_
#define __EEPROM_H_

#define EEPROM_MODE_ADDR	0
#define EEPROM_V_RATIO_ADDR	4
#define EEPROM_I_RATIO_ADDR	8
#define EEPROM_I_ZERO_ADDR	16

//EEPOROM
#define ENABLE_IAP 			0x83           //if SYSCLK<12MHz


#define CMD_IDLE    		0               //����ģʽ
#define CMD_READ    		1               //IAP�ֽڶ�����
#define CMD_PROGRAM 		2               //IAP�ֽڱ������
#define CMD_ERASE   		3               //IAP������������

#define USED_BYTE_QTY_IN_ONE_SECTOR     128

void IapIdle(void);
unsigned char IapReadByte(unsigned short addr);
void IapProgramByte(unsigned short addr, unsigned char dat);
void IapEraseSector(unsigned short addr);
void IapSaveData(unsigned short addr, unsigned char *array, unsigned char len);
void IapReadData(unsigned short addr, long *num);

#endif
