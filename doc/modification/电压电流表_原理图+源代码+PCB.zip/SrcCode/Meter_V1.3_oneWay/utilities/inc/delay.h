#ifndef __DELAY_H_
#define __DELAY_H_


void delay_ms(unsigned int del);


#endif

