#include "stc15.h"
#include "delay.h"


void delay_ms(unsigned int del)		//@11.0592MHz 1ms
{
	unsigned int i=0;
	unsigned int j=0;
	
	for(i=0; i<del; i++)
	{
		j = 578;
		while(j--)
		{
			_nop_();
		}
	}
}



