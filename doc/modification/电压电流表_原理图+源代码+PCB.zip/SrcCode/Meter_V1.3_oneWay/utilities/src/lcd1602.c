#include "STC15.h"
#include "lcd1602.h"
#include "delay.h"


#define LCD_RS		P13
#define LCD_EN		P12
#define LCD_DATA0	P33
#define LCD_DATA1	P32
#define LCD_DATA2	P31
#define LCD_DATA3	P30


static void LCD_Delay(void);
static void LCD1602_GGRAM(unsigned char *chr);

/***************************************************
 *
 */
static void LCD_Delay(void)
{
	unsigned char i=50;
	while(i--) { _nop_(); }
}

/***************************************************
 *
 */
void LCD1602_Config(void)
{
	unsigned char i=0;
	unsigned char ohm_chr[8]={0x0E,0x11,0x11,0x11,0x0A,0x0A,0x1B,0x00};
	
	for(i=0; i<3; i++)
	{
		LCD1602_Write(LCD_WR_CMD, 0x28);
		delay_ms(50);
	}
	
	LCD_EN = 1;
	LCD_Delay();
	LCD_EN = 0;
	LCD1602_Write(LCD_WR_CMD, 0x28);
	LCD1602_Write(LCD_WR_CMD, 0x0C);
	LCD1602_Write(LCD_WR_CMD, 0x01);
	delay_ms(10);
	
	LCD1602_GGRAM(ohm_chr);
	LCD1602_WriteString(1, 0, "Welcome to use", 14);
}

/***************************************************
 *
 */
static void LCD1602_GGRAM(unsigned char *chr)
{
	unsigned char i;
	
	for(i=0; i<8; i++)
	{
		LCD1602_Write(LCD_WR_CMD, 0x40+i);
		LCD1602_Write(LCD_WR_DATA, *chr);
		chr++;
	}
}

/***************************************************
 *
 */
void LCD1602_Write(unsigned char type, unsigned char res)
{
	LCD_RS = (type==LCD_WR_CMD)?0:1;

	LCD_DATA3 = res&0x80;
	LCD_DATA2 = res&0x40;
	LCD_DATA1 = res&0x20;
	LCD_DATA0 = res&0x10;
	
	LCD_EN = 1;
	LCD_Delay();
	LCD_EN = 0;

	LCD_DATA3 = res&0x08;
	LCD_DATA2 = res&0x04;
	LCD_DATA1 = res&0x02;
	LCD_DATA0 = res&0x01;
	
	LCD_EN = 1;
	LCD_Delay();
	LCD_EN = 0;
}

/***************************************************
 *
 */
void LCD1602_WriteChar(unsigned char x, unsigned char y, unsigned char chr)
{
	unsigned char address=0;
	if(y==0) { address = 0x80 + x; }
	else { address = 0xC0 + x; }
	LCD1602_Write(LCD_WR_CMD, address);
	LCD1602_Write(LCD_WR_DATA, chr);
}

/***************************************************
 *
 */
void LCD1602_WriteString(unsigned char x, unsigned char y, unsigned char *chr, unsigned char len)
{
	while(len--)
	{
		LCD1602_WriteChar(x, y, *chr);
		x++;
		chr++;
	}
}

unsigned long MyPow(unsigned char m, unsigned char n)
{
	unsigned long result=1;	 
	while(n--)
	{
		result *= m;    
	}
	return result;
}

/***************************************************
 *
 */
void DisplayNumber(unsigned char x, unsigned char y, long num, unsigned char type)
{
	unsigned char temp=0;
	unsigned char i=0,j=0;
	unsigned char len=4, pBit=5, pos=2;
	unsigned char dis_buff[8];

	if(num<=0) 
	{
		num=0; 
		if(type==DIS_R)
		{
			LCD1602_WriteString(x, y, " Noload", 8);
			return ;
		}
	}
	
	if(num>=1e5 && num<1e6)
	{
		pos = 3;
		len = 5;
	}
	else if(num>=1e6)
	{
		if(num>1e7)
		{
			num = 9999999;
		}
		pos = 4;
		len = 6;
	}
	
	if(type==0xFF)
	{
		pBit = 6;
		pos = 0;
		len = 5;
	}
	
	j=0;
	for(i=0; i<pBit; i++)
	{
		temp = (num / MyPow(10, len-i)) % 10;
		if(i!=0 && pos==i)
		{
				dis_buff[j] = '.';
				j++;
		}
		if(i==0 && temp==0)
		{
			dis_buff[j] = ' ';
		}
		else
		{
			dis_buff[j] = temp + 0x30;
		}
		j++;
	}
	
	
	if(type=='H')
	{
		dis_buff[6] = 'A';
		dis_buff[7] = 'H';
	}
	else if(type==0xFF)
	{
		dis_buff[6] = ' ';
		dis_buff[7] = ' ';
	}
	else
	{
		dis_buff[6] = type;
		dis_buff[7] = ' ';
	}
	LCD1602_WriteString(x, y, dis_buff, 8);
}

/***************************************************
 *
 */
void DisplayTimer(unsigned char h, unsigned char m, unsigned char s)
{
	unsigned char dis_buff[8];
	
	dis_buff[0] = ((h / 10) % 10) + 0x30;
	dis_buff[1] = (h % 10) + 0x30;
	dis_buff[2] = ':';
	dis_buff[3] = ((m / 10) % 10) + 0x30;
	dis_buff[4] = (m % 10) + 0x30;
	dis_buff[5] = ':';
	dis_buff[6] = ((s / 10) % 10) + 0x30;
	dis_buff[7] = (s % 10) + 0x30;

	LCD1602_WriteString(8, 1, dis_buff, 8);
}














