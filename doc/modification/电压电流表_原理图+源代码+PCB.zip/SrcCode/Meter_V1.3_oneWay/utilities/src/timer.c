#include "STC15.h"
#include "timer.h"


void Timer_Config(void)
{
	//timer0
	AUXR |= 0x80;  //1T mode
	TMOD = 0x00;  
	TL0 = T0MS; 
	TH0 = T0MS >> 8;
	TR0 = 1; 
	ET0 = 1; 
}

