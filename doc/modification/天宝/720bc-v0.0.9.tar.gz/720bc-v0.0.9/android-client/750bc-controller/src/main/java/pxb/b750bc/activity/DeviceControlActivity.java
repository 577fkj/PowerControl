package pxb.b750bc.activity;

import android.app.ActionBar;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.tencent.bugly.crashreport.CrashReport;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import pxb.b750bc.R;
import pxb.b750bc.Utils;
import pxb.b750bc.bluetooth.DeviceListActivity;

public final class DeviceControlActivity extends BaseActivity {
    private static final String DEVICE_NAME = "DEVICE_NAME";

    private static String MSG_NOT_CONNECTED;
    private static String MSG_CONNECTING;
    private static String MSG_CONNECTED;

    private static BluetoothResponseHandler mHandler = new BluetoothResponseHandler();

    private EditText commandEditText;
    private String deviceName;

    TextView log;
    private Switch relay;
    private Switch on;
    private Switch fan;
    private SeekBar voltage_percent;
    private SeekBar current_percent;
    private TextView voltage;
    private TextView current;
    private TextView battery_voltage;

    float r52 = 33.2f;
    float r48_r50 = 750f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        PreferenceManager.setDefaultValues(this, R.xml.settings_activity, false);

        final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.OnSharedPreferenceChangeListener listener1 = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                try {
                    r52 = Float.parseFloat(sharedPreferences.getString("r52", "33.2"));
                } catch (NumberFormatException ignore) {
                    r52 = 33.2f;
                }
                try {
                    r48_r50 = Float.parseFloat(sharedPreferences.getString("r48_r50", "750"));
                } catch (NumberFormatException ignore) {
                    r48_r50 = 750f;
                }
            }
        };
        listener1.onSharedPreferenceChanged(settings, "R1");
        settings.registerOnSharedPreferenceChangeListener(listener1);

        mHandler.setTarget(this);

        MSG_NOT_CONNECTED = getString(R.string.msg_not_connected);
        MSG_CONNECTING = getString(R.string.msg_connecting);
        MSG_CONNECTED = getString(R.string.msg_connected);

        setContentView(R.layout.activity_terminal);
        if (isConnected() && (savedInstanceState != null)) {
            setDeviceName(savedInstanceState.getString(DEVICE_NAME));
        } else getActionBar().setSubtitle(MSG_NOT_CONNECTED);

        this.log = findViewById(R.id.log_textview);

        View.OnClickListener listener = v -> {
            Switch s = (Switch) v;
            doSend(s.getTag() + (s.isChecked() ? "1" : "0"));
        };

        this.relay = (Switch) findViewById(R.id.继电器);
        this.on = (Switch) findViewById(R.id.初级);
        this.fan = (Switch) findViewById(R.id.散热器);

        this.relay.setOnClickListener(listener);
        this.fan.setOnClickListener(listener);
        this.on.setOnClickListener(listener);


        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    StringBuilder sb = new StringBuilder();
                    while (progress != 0) {
                        sb.append(progress % 10);
                        progress /= 10;
                    }
                    doSend(seekBar.getTag() + sb.toString());
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        };
        this.voltage_percent = findViewById(R.id.voltage_percent);
        voltage_percent.setOnSeekBarChangeListener(l);
        this.current_percent = findViewById(R.id.current_percent);
        current_percent.setOnSeekBarChangeListener(l);
        this.voltage = findViewById(R.id.voltage);
        this.current = findViewById(R.id.current);
        this.battery_voltage = findViewById(R.id.battery_voltage);

        this.commandEditText = (EditText) findViewById(R.id.command_edittext);
        // soft-keyboard send button
        this.commandEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendCommand(null);
                return true;
            }
            return false;
        });
        // hardware Enter button
        this.commandEditText.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    sendCommand(null);
                    return true;
                }
            }
            return false;
        });

        ((Button) findViewById(R.id.btn_fan_mod_3))
                .setOnClickListener(v -> doSend("f3"));
        ((Button) findViewById(R.id.btn_auto_fan))
                .setOnClickListener(v -> doSend("f2"));
        ((Button) findViewById(R.id.btn_write))
                .setOnClickListener(v -> doSend("W1"));

        String version = "?";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignore) {

        }
        ((TextView) findViewById(R.id.display_version)).setText("控制端版本: " + version);
    }

    private boolean isConnected() {
        return mmSocket != null && mmSocket.isConnected();
    }

    // ==========================================================================

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(DEVICE_NAME, deviceName);
    }
    // ============================================================================

    /**
     * Список устройств для подключения
     */
    private void startDeviceListActivity() {
        Intent serverIntent = new Intent(this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
    }
    // ============================================================================


    /**
     * Обработка аппаратной кнопки "Поиск"
     *
     * @return
     */
    @Override
    public boolean onSearchRequested() {
        if (super.isAdapterReady()) startDeviceListActivity();
        return false;
    }
    // ==========================================================================


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.device_control_activity, menu);
        final MenuItem bluetooth = menu.findItem(R.id.menu_search);
        if (bluetooth != null) bluetooth.setIcon(this.isConnected() ?
                R.drawable.ic_action_device_bluetooth_connected :
                R.drawable.ic_action_device_bluetooth);
        return true;
    }
    // ============================================================================


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.menu_search) {
            if (super.isAdapterReady()) {
                startDeviceListActivity();
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                if (checkBluetoothPermission(REQUEST_ENABLE_BT))
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            return true;
//        } else if (itemId == R.id.menu_clear) {
//            return true;
//        } else if (itemId == R.id.menu_send) {
//            return true;
        } else if (itemId == R.id.menu_settings) {
            final Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    // ============================================================================


    @Override
    public void onStart() {
        super.onStart();
        commandEditText.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        commandEditText.setFilters(new InputFilter[]{});
    }
    // ============================================================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    String address = data.getStringExtra(DeviceListActivity.EXTRA_DEVICE_ADDRESS);

                    startConnect(address);
                }
                break;
            case REQUEST_ENABLE_BT:
                // When the request to enable Bluetooth returns
                super.pendingRequestEnableBt = false;
                if (resultCode != Activity.RESULT_OK) {
                    Utils.log("BT not enabled");
                }
                checkBluetoothPermission(REQUEST_ENABLE_BT);
                break;
        }
    }


    static class Msg {
        int R, F, O, T, I, B, C, V, A, c, v, M, S, D;

        @Override
        public String toString() {

            double temp;
            {
                double Rntc = 33.0 / (T / 1000.0) - 10; // k
                double B = 3950; // or 3950;
                double Ka = 273.15;
                double T25 = Ka + 25;
                double R25 = 100; // k
                // 换算温度为摄氏度
                temp = 1.0 / (1.0 / T25 + (Math.log(Rntc) - Math.log(R25)) / B) - Ka;
            }

            return "继电器=" + (R != 0 ? "On" : "Off") +
                    ", 风扇=" + (F != 0 ? "On" : "Off") +
                    ", 初级=" + (O != 0 ? "On" : "Off") + "\n" +
//                    ", mcu参考电压=" + String.format("%dmV", I) +
//                    ", A=" + String.format("%.03fV", VAC) +
                    "输出电压占空比=" + String.format("%.02f%%", v / 100.0) +
                    ", 输出电流占空比=" + String.format("%.02f%%", c / 100.0) + "\n" +
//                    ", M=" + M +
//                    ", S=" + S +
//                    ", D=" + D +
                    "温度=" + String.format("%.1f℃", temp) + "\n"

                    ;
        }
    }

    String gline;

    private void onMsg(String line) {
        if (line == null || line.length() == 0) {
            return;
        }
        Msg m = new Msg();
        if (!line.startsWith(">")) {
            Log.d("XX", line);
            gline = line;
            return;
        }
        byte[] cmd_buff = line.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < cmd_buff.length; ) {
            int cmd = cmd_buff[i];
            i++;
            int v = 0;
            int base = 1;
            while (i < cmd_buff.length) {
                int x2 = cmd_buff[i];
                if (x2 >= '0' && x2 <= '9') {
                    v += (x2 - '0') * base;
                    base *= 10;
                    i++;
                } else {
                    break;
                }
            }
            switch (cmd) {
                case 'R':
                    m.R = v;
                    break;
                case 'F':
                    m.F = v;
                    break;
                case 'O':
                    m.O = v;
                    break;
                case 'T': {
                    m.T = v;
                }
                break;
                case 'I':
                    m.I = v;
                    break;
                case 'B':
                    m.B = v;
                    break;
                case 'C':
                    m.C = v;
                    break;
                case 'V':
                    m.V = v;
                    break;
                case 'A':
                    m.A = v;
                    break;
                case 'c':
                    m.c = v;
                    break;
                case 'v':
                    m.v = v;
                    break;
                case 'M':
                    m.M = v;
                    break;
                case 'S':
                    m.S = v;
                    break;
                case 'D':
                    m.D = v;
                    break;
            }
        }

        mHandler.obtainMessage(MESSAGE_ON_CMD, m).sendToTarget();
    }

    BluetoothSocket mmSocket;
    OutputStream os;

    /**
     * Установка соединения с устройством
     */
    private void startConnect(String address) {
        new Thread(() -> {
//            stopConnection();
            try {
                mHandler.obtainMessage(STATE_CONNECTING).sendToTarget();
                BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice connectedDevice = btAdapter.getRemoteDevice(address);
                String name = connectedDevice.getAlias();
                if (name == null) {
                    name = connectedDevice.getName();
                }
                mHandler.obtainMessage(DeviceControlActivity.MESSAGE_DEVICE_NAME, name).sendToTarget();
                UUID SSP = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
                mmSocket = connectedDevice.createRfcommSocketToServiceRecord(SSP);
                mmSocket.connect();
                BufferedReader is = new BufferedReader(new InputStreamReader(mmSocket.getInputStream(), "UTF-8"));
                os = mmSocket.getOutputStream();
                mHandler.obtainMessage(STATE_CONNECTED, name).sendToTarget();


                new Thread(() -> {
                    try {
                        while (mmSocket.isConnected()) {
                            String line = is.readLine();
                            if (line != null) {
                                onMsg(line);
                            } else {
                                break;
                            }
                        }
                    } catch (Exception ignore) {
                    } finally {
                        try {
                            is.close();
                        } catch (IOException ignore) {
                        }
                    }
                    mHandler.obtainMessage(STATE_LOST).sendToTarget();
                }).start();

            } catch (Exception e) {
                mHandler.obtainMessage(STATE_LOST).sendToTarget();
                Utils.log("setupConnector failed: " + e.getMessage());
            }
        }).start();
    }
    // ==========================================================================


    /**
     * Отправка команды устройству
     */
    public void sendCommand(View view) {
        String commandString = commandEditText.getText().toString();
        doSend(commandString);

        commandEditText.setText("");
    }

    private void doSend(String commandString) {
        if (isConnected()) {
            try {
                os.write(("<" + commandString + "\r\n").getBytes(StandardCharsets.UTF_8));
                os.flush();
            } catch (IOException ignore) {
            }
        }
    }
    // ==========================================================================

    void appendLog(Msg msg) {
        on.setChecked(msg.O != 0);
        fan.setChecked(msg.F != 0);
        relay.setChecked(msg.R != 0);


        current_percent.setProgress(msg.c);
        voltage_percent.setProgress(msg.v);

        double vRef = 0.584; // R1 R3
        double CURRENT = (msg.C / 1000.0 - vRef) / 0.216;

        double VOLTAGE = msg.V * (r52 + r48_r50) / r52 / 1000.0;

        voltage.setText(String.format("%.01fV", VOLTAGE));
        current.setText(String.format("%.02fA", CURRENT));


        double VBattery = msg.B / 1000.0 * 23.59036;
        battery_voltage.setText(String.format("电池 %.01fV", VBattery));


        String text = msg.toString();
        if (gline != null && gline.length() > 0) {
            text += "服务端信息:" + gline + "\n";
        }
        log.setText(text);
    }
    // =========================================================================


    void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
        getActionBar().setSubtitle(deviceName);
    }
    // ==========================================================================

    /**
     * Обработчик приёма данных от bluetooth-потока
     */
    private static class BluetoothResponseHandler extends Handler {
        private WeakReference<DeviceControlActivity> mActivity = new WeakReference<DeviceControlActivity>(null);

        public BluetoothResponseHandler() {

        }

        public void setTarget(DeviceControlActivity target) {
            mActivity.clear();
            mActivity = new WeakReference<DeviceControlActivity>(target);
        }

        @Override
        public void handleMessage(Message msg) {
            DeviceControlActivity activity = mActivity.get();

            if (activity != null) {
                final ActionBar bar = activity.getActionBar();
                switch (msg.what) {
                    case STATE_CONNECTED: {
                        String deviceName = (String) msg.obj;
                        bar.setSubtitle(deviceName + " " + MSG_CONNECTED);
                        activity.invalidateOptionsMenu();
                    }
                    break;
                    case STATE_CONNECTING: {
                        String deviceName = (String) msg.obj;
                        bar.setSubtitle(deviceName + " " + MSG_CONNECTING);
                        activity.invalidateOptionsMenu();
                    }
                    break;
                    case STATE_LOST:
                    case STATE_NONE:
                        bar.setSubtitle(MSG_NOT_CONNECTED);
                        activity.invalidateOptionsMenu();
                        break;

                    case MESSAGE_ON_CMD:
                        final Msg cmd = (Msg) msg.obj;
                        if (cmd != null) {
                            activity.appendLog(cmd);
                        }
                        break;

                    case MESSAGE_DEVICE_NAME:
                        activity.setDeviceName((String) msg.obj);
                        break;

                    case MESSAGE_WRITE:
                        // stub
                        break;
                }
            }
        }
    }
    // ==========================================================================
}