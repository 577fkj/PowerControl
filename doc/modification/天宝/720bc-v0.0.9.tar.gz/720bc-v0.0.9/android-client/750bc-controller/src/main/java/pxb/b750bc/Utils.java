package pxb.b750bc;

import android.util.Log;

/**
 * Вспомогательные методы
 * Created by sash0k on 29.01.14.
 */
public class Utils {

    /**
     * Общий метод вывода отладочных сообщений в лог
     */
    public static void log(String message) {
//        if (BuildConfig.DEBUG) {
            if (message != null) Log.i(Const.TAG, message);
//        }
    }
    // ============================================================================

    // ============================================================================

    public static int formatNumber(String input) {
        int value;
        try {
            value = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            value = 0;
        }
        return value;
    }
}
