/* USER CODE BEGIN Header */
/**
    750bc
    Copyright (C) 2023  bob pan

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <assert.h>
#include "stm32f0xx_ll_adc.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;
DMA_HandleTypeDef hdma_adc;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_ADC_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

typedef enum {
	POWER_MODE = 0
} mode_t;

mode_t mode = POWER_MODE;

typedef struct {
	uint16_t voltage_adc_max;
	uint16_t current_pwm_percent;
	uint16_t voltage_pwm_percent;
} charger_stage_t;

typedef struct {
	uint16_t total_stages;
	charger_stage_t stages[4];
	uint16_t current_adc_finish;
} charger_profile_t;

const static charger_profile_t profiles[8] = { //
		{ .total_stages = 0, .stages = { }, .current_adc_finish = 33000 }, // 0
		{ .total_stages = 4, .stages = { { 3300 } },.current_adc_finish = 100 }, // 1
		// TODO 添加其他充电信息
		};

typedef struct {
	uint16_t stage;
	uint8_t done;
	uint32_t first_ready_ms;
	uint8_t stage_set_flags;
} charger_t;

static charger_t charger;

#define ADC_CHANNEL_NUM 6
#define ADC_SAMPLE_NUM 40

// ADC-DMA持续采样 40组
// [IN0, IN1, ..., IN0, IN1, ...]
uint16_t adc_values[ADC_CHANNEL_NUM * ADC_SAMPLE_NUM] = {0};

uint16_t average_u16(int offset) {
	uint32_t sum = 0;
	for (int i = 0; i < ADC_SAMPLE_NUM; i ++) {
		sum += adc_values[i * ADC_CHANNEL_NUM + offset];
	}
	return (uint16_t) (sum / (uint32_t)ADC_SAMPLE_NUM);
}

#define CHANNEL_PWM_CURRENT TIM_CHANNEL_1
#define CHANNEL_PWM_VOLTAGE TIM_CHANNEL_2

uint16_t s_current_pwm_percent = 0;
uint16_t s_voltage_pwm_percent = 0;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (GPIO_Pin == PROTECTION_Pin) {
		HAL_GPIO_WritePin(ON_GPIO_Port, ON_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(RELAY_GPIO_Port, RELAY_Pin, GPIO_PIN_RESET);
	}
}

static void set_relay(GPIO_PinState state) {
	if (state == GPIO_PIN_SET) {
		if (HAL_GPIO_ReadPin(PROTECTION_GPIO_Port, PROTECTION_Pin) == GPIO_PIN_RESET) {
			// 反接保护
			return;
		}
	}

	if (state == GPIO_PIN_RESET
			&& HAL_GPIO_ReadPin(RELAY_GPIO_Port, RELAY_Pin) == GPIO_PIN_SET) {
		// to protect the relay, disconnect main power
		HAL_GPIO_WritePin(ON_GPIO_Port, ON_Pin, GPIO_PIN_RESET);
		// 这里不能等, 可能中断中等太久了, 等挂了
		// HAL_Delay(3); // 3ms;
	}

	HAL_GPIO_WritePin(RELAY_GPIO_Port, RELAY_Pin, state);
}

static HAL_StatusTypeDef set_pulse(uint32_t channel, uint16_t percent /* 10000 based */) {
	if (channel == CHANNEL_PWM_CURRENT) {
		s_current_pwm_percent = percent;
	} else {
		s_voltage_pwm_percent = percent;
	}
//	if (percent == 0) {
//		__HAL_TIM_SET_COMPARE(&htim1, channel, 0);
//		TIM_CCxChannelCmd(htim1.Instance, channel, TIM_CCx_DISABLE);
//
//		return HAL_OK;
//	}

	uint16_t pulse = (htim1.Init.Period + 1) * percent / 10000u;
	if (pulse > 0) {
		pulse--;
	}

	__HAL_TIM_SET_COMPARE(&htim1, channel, pulse);
	TIM_CCxChannelCmd(htim1.Instance, channel, TIM_CCx_ENABLE);

	return HAL_OK;
}

#define STORE_MAGIC 0x89757000abcd0001UL
typedef struct {
	uint16_t s_current_pwm_percent;
	uint16_t s_voltage_pwm_percent;
	uint8_t on; // GPIO_PinState
	uint8_t relay; // GPIO_PinState
	uint8_t fan;
	uint8_t padding;
	uint64_t magic; // magic must put last
} stored_data_t;

uint8_t uart_rx_buff[32];
uint8_t cmd_buff[64];
uint8_t cmd_buff_pos = 0;
uint8_t cmd_buff_size = 0;

HAL_StatusTypeDef last_rx_status = HAL_BUSY;

static void dma_rx_receive() {
	if (last_rx_status != HAL_OK) {
		last_rx_status = HAL_UARTEx_ReceiveToIdle_DMA(&huart1, uart_rx_buff,
				sizeof(uart_rx_buff));
		__HAL_DMA_DISABLE_IT(&hdma_usart1_rx, DMA_IT_HT);
	}
}

uint8_t uart_tx_buff[96];

typedef enum {
	FAN_FORCE_OFF = 0,
	FAN_FORCE_ON = 1,
	FAN_AUTO = 2,
	FAN_MOD_3 = 3,
} fan_ctrl_t;

fan_ctrl_t fan_ctrl = FAN_AUTO;
uint8_t write_ctrl = 0;

void on_cmds() {
	uint8_t start = (cmd_buff_pos + sizeof(cmd_buff) - cmd_buff_size) % sizeof(cmd_buff);
	uint8_t head = cmd_buff[start];
	if (head != '<') {
		return;
	}
	for (uint16_t i = 0; i < cmd_buff_size;) {
		uint8_t cmd = cmd_buff[(start + i) % sizeof(cmd_buff)];
		i++;
		uint16_t v = 0;
		uint16_t base =1;
		while (i < cmd_buff_size) {
			uint8_t x2 = cmd_buff[(start + i) % sizeof(cmd_buff)];
			if (x2 >= '0' && x2 <= '9') {
				v += (x2 - '0') * base;
				base *= 10u;
				i++;
			} else {
				break;
			}
		}
		switch (cmd) {
		case 'v':
			if (mode == POWER_MODE) {
				set_pulse(CHANNEL_PWM_VOLTAGE, v);
			}
			break;
		case 'c':
			if (mode == POWER_MODE) {
				set_pulse(CHANNEL_PWM_CURRENT, v);
			}
			break;
		case 'O':
			HAL_GPIO_WritePin(ON_GPIO_Port, ON_Pin,
					v == 0 ? GPIO_PIN_RESET : GPIO_PIN_SET);
			break;
		case 'R':
			set_relay(v == 0 ? GPIO_PIN_RESET : GPIO_PIN_SET);
			break;
		case 'f':
			fan_ctrl = v;
			break;
		case 'W':
			write_ctrl = v;
			break;
		}
	}
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t size) {
	if (huart == &huart1) {
		for (uint16_t i = 0; i < size; i++) {
			uint8_t d = uart_rx_buff[i];
			if (d == '\n' || d == '\r') {
				if (cmd_buff_size > 0) {
					on_cmds();
				}
				cmd_buff_size = 0;
				continue;
			}

			cmd_buff[cmd_buff_pos] = d;
			cmd_buff_pos = (cmd_buff_pos + 1) % (uint8_t) sizeof(cmd_buff);

			cmd_buff_size += 1;
			if (cmd_buff_size > sizeof(cmd_buff)) {
				cmd_buff_size = sizeof(cmd_buff);
			}
		}



		last_rx_status = HAL_BUSY;
		dma_rx_receive();
	}
}

void write(const stored_data_t *stored) {
	stored_data_t w = { //
			.s_current_pwm_percent = s_current_pwm_percent, //
					.s_voltage_pwm_percent = s_voltage_pwm_percent, //
					.on = HAL_GPIO_ReadPin(ON_GPIO_Port, ON_Pin), //
					.relay = HAL_GPIO_ReadPin(RELAY_GPIO_Port, RELAY_Pin), //
					.fan = fan_ctrl, //
					.magic = STORE_MAGIC };

	uint32_t base = (uint32_t) stored;
	if (HAL_OK == HAL_FLASH_Unlock()) {

		FLASH_EraseInitTypeDef s = { .TypeErase = FLASH_TYPEERASE_PAGES,
				.PageAddress = (uint32_t) stored, .NbPages = 1 };

		uint32_t PageError = 0;

		__disable_irq();

		// HAL_StatusTypeDef r = //
		HAL_FLASHEx_Erase(&s, &PageError);

		__enable_irq();

		for (int i = 0; i < sizeof(stored_data_t); i += 8) {
			// HAL_StatusTypeDef result =
			HAL_FLASH_Program(
			FLASH_TYPEPROGRAM_DOUBLEWORD, base + i,
					*(uint64_t*) (((uint8_t*) &w) + i));
		}
		HAL_FLASH_Lock();
	}
}

uint32_t loop_count = 0;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_ADC_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

    // 绿色指示等亮起来
	HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);

	HAL_ADCEx_Calibration_Start(&hadc);

	HAL_TIM_PWM_Start(&htim1, CHANNEL_PWM_CURRENT);
	HAL_TIM_PWM_Start(&htim1, CHANNEL_PWM_VOLTAGE);

	set_pulse(CHANNEL_PWM_CURRENT, 0);
	set_pulse(CHANNEL_PWM_VOLTAGE, 0);

	HAL_ADC_Start_DMA(&hadc, (uint32_t*) adc_values,
			sizeof(adc_values) / sizeof(uint16_t));

	  HAL_Delay(1000); // ms 等待蓝牙模块启动完成，忽略蓝牙模块的数据
	  // 改掉蓝牙名称
	  HAL_UART_Transmit(&huart1, (const uint8_t*) "AT+BDSPP_S750BC7201005\r\n", 24, 1000);
	  HAL_Delay(1000); // ms
	  // 重启蓝牙模块
	  HAL_UART_Transmit(&huart1, (const uint8_t*) "AT+CZ\r\n", 7, 1000);
	  HAL_Delay(1000); // ms
//	  HAL_UART_Transmit(&huart1, (const uint8_t*) "AT+BMBLE_S750BC7201005\r\n", 24, 1000);
//	  HAL_Delay(3000); // ms
//	  HAL_UART_Transmit(&huart1, (const uint8_t*) "AT+CZ\r\n", 7, 1000);
//	  HAL_Delay(3000); // ms

	// 读取拨码开关配置
//	mode = (HAL_GPIO_ReadPin(BOMA3_GPIO_Port, BOMA3_Pin) << 0)
//			| (HAL_GPIO_ReadPin(BOMA4_GPIO_Port, BOMA4_Pin) << 1)
//			| (HAL_GPIO_ReadPin(BOMA5_GPIO_Port, BOMA5_Pin) << 2)
//			| (HAL_GPIO_ReadPin(BOMA6_GPIO_Port, BOMA6_Pin) << 3);


	const stored_data_t *stored = (const stored_data_t*) (FLASH_BANK1_END + 1
			- FLASH_PAGE_SIZE);
	if (HAL_OK == HAL_FLASH_Unlock()) {
		if (stored->magic == STORE_MAGIC) {

			set_relay(stored->relay);
			HAL_GPIO_WritePin(ON_GPIO_Port, ON_Pin, stored->on);

			fan_ctrl = stored->fan;
			set_pulse(CHANNEL_PWM_VOLTAGE, stored->s_voltage_pwm_percent);
			set_pulse(CHANNEL_PWM_CURRENT, stored->s_current_pwm_percent);
		}
		HAL_FLASH_Lock();
	}


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);

		if (write_ctrl) {
			write_ctrl = 0;
			write(stored);
		}

	  dma_rx_receive();
		// 每秒钟显示2次，
		HAL_Delay(500); // ms

		GPIO_PinState relay = HAL_GPIO_ReadPin(RELAY_GPIO_Port, RELAY_Pin);
		GPIO_PinState on = HAL_GPIO_ReadPin(ON_GPIO_Port, ON_Pin);
		GPIO_PinState fan = HAL_GPIO_ReadPin(FAN_GPIO_Port, FAN_Pin);
		GPIO_PinState protection = HAL_GPIO_ReadPin(PROTECTION_GPIO_Port,
				PROTECTION_Pin);

		if (protection == GPIO_PIN_RESET && relay == GPIO_PIN_SET) { // 反接了
			set_relay(GPIO_PIN_RESET);
			relay = GPIO_PIN_RESET;
		}

		// red 充电指示 = 继电器
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin,
				relay == GPIO_PIN_SET ? GPIO_PIN_RESET : GPIO_PIN_SET);


		uint16_t vref = __LL_ADC_CALC_VREFANALOG_VOLTAGE(average_u16(ADC_CHANNEL_NUM - 1), ADC_RESOLUTION_12B);// in mV

		//		// 计算各个ADC的平均电压
		uint16_t ADC_TEMP = __LL_ADC_CALC_DATA_TO_VOLTAGE(vref, average_u16(0), ADC_RESOLUTION_12B);// in mV
		uint16_t ADC_CURRENT = __LL_ADC_CALC_DATA_TO_VOLTAGE(vref, average_u16(1), ADC_RESOLUTION_12B);// in mV
		uint16_t ADC_VB = __LL_ADC_CALC_DATA_TO_VOLTAGE(vref, average_u16(2), ADC_RESOLUTION_12B);// in mV
		uint16_t ADC_VOUT = __LL_ADC_CALC_DATA_TO_VOLTAGE(vref, average_u16(3), ADC_RESOLUTION_12B);// in mV
		uint16_t ADC_AC_UV = __LL_ADC_CALC_DATA_TO_VOLTAGE(vref, average_u16(4), ADC_RESOLUTION_12B);// in mV

//		uint16_t Cinternal=	__LL_ADC_CALC_TEMPERATURE(vref, average_u16(d, sizeof(d) / sizeof(uint16_t), 6), ADC_RESOLUTION_12B); // degree Celsius

		//https://blog.csdn.net/lowkeyaaaa/article/details/118526046
		// 3.3 / (Rntc + 10) = Vadc_tmp / 10
//		double Rntc = 33.0 / ADC_TEMP - 10; // k
//		double B = 3950; // or 3950;
//		double Ka = 273.15;
//		double T25 = Ka + 25;
//		double R25 = 100; // k
//		// 换算温度为摄氏度
//		double temp = 1.0 / (1.0 / T25 + (log(Rntc) - log(R25)) / B) - Ka;

		// http://www.minchuangdianzi.com/document/131.html
		// C    kOhms   mVolt
		// 35	65.2411 438.59
		// 45	43.5621 616.11
		// 70	17.3452 1206.79
		uint16_t fan_off = 438;
		uint16_t fan_on = 616;
		uint16_t over_heat = 1206;

		// ADC_CURRENT 读数是 800 mv 时, 输出 1A
		// 822 输出 1.1A
		// 778 输出 0.9A

		// 自动模式: 风扇45度开启，35度关闭
		// 模式3: 在自动模式基础上 > 1.1A开启 < 0.9A关闭

		if (fan == GPIO_PIN_SET) { // 风扇已经开启, 看一下是否要关闭
			if (fan_ctrl == FAN_FORCE_OFF
					|| (fan_ctrl == FAN_AUTO && ADC_TEMP <= fan_off)
					|| (fan_ctrl == FAN_MOD_3 && ADC_TEMP <= fan_off
							&& ADC_CURRENT <= 778)) {
				HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_RESET);
				fan = GPIO_PIN_RESET;
			}
		} else if (fan == GPIO_PIN_RESET) { // 风扇已经关闭, 看一下是否要开启
			if (fan_ctrl == FAN_FORCE_ON
					|| (fan_ctrl == FAN_AUTO && ADC_TEMP >= fan_on)
					|| (fan_ctrl == FAN_MOD_3
							&& (ADC_TEMP >= fan_on || ADC_CURRENT >= 822))) {
				HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_SET);
				fan = GPIO_PIN_SET;
			}
		}

		if (ADC_TEMP > over_heat) { // 过温度保护
			// 断开输出
			set_relay(GPIO_PIN_RESET);
			relay = GPIO_PIN_RESET;
			on = GPIO_PIN_RESET;
			set_pulse(CHANNEL_PWM_CURRENT, 0);
			set_pulse(CHANNEL_PWM_VOLTAGE, 0);
		}

		if (mode != POWER_MODE) { // 充电模式
			const charger_profile_t* profile = &profiles[mode];
			if (charger.stage >= profile->total_stages) {
				// 断开输出
				set_relay(GPIO_PIN_RESET);
				set_pulse(CHANNEL_PWM_CURRENT, 0);
				set_pulse(CHANNEL_PWM_VOLTAGE, 0);
				charger.done = 1;
			} else if (charger.stage_set_flags & (1 << charger.stage)) {
				const charger_stage_t *p = &profile->stages[charger.stage];
				const uint32_t m = HAL_GetTick();

				if (ADC_VB >= (((uint32_t) p->voltage_adc_max) * 98u / 100u)) { // 电压已经到98%以上, 有些余量
					if (charger.first_ready_ms == 0) {
						charger.first_ready_ms = m;
					} else {
						if (m > charger.first_ready_ms + 5000) {
							if (charger.stage == profile->total_stages - 1) { // 最后一个阶段
								if (ADC_CURRENT < profile->current_adc_finish) { // 判断截止电流
									charger.stage++; // 下个阶段了
									charger.first_ready_ms = 0;
								}
							} else { // 中间阶段，直接往下
								charger.stage++; // 下个阶段了
								charger.first_ready_ms = 0;
							}
						}
					}
				} else {
					charger.first_ready_ms = 0;
				}
			} else {
				const charger_stage_t *p = &profile->stages[charger.stage];
				set_pulse(CHANNEL_PWM_CURRENT, p->current_pwm_percent);
				set_pulse(CHANNEL_PWM_VOLTAGE, p->voltage_pwm_percent);
				set_relay(GPIO_PIN_SET);
				HAL_GPIO_WritePin(ON_GPIO_Port, ON_Pin, GPIO_PIN_SET);

				charger.stage_set_flags |= (1 << charger.stage);
			}
		}

		if (loop_count % 20 == 0) {
			HAL_UART_Transmit(&huart1, (uint8_t*) " 0.0.9\r\n", 8, 500);
		}
		loop_count ++;

		int i = 0;
		uint8_t *buff = uart_tx_buff;

#define W16(k, value) do { buff[i++] =k; uint16_t  t = value; while(t) { buff[i++]  = '0'+ (t % 10u); t= t/10u;     }  } while(0);
		buff[i++] = '>';
		W16('R', (uint16_t ) relay);
		W16('F', (uint16_t ) fan);
		W16('O', (uint16_t ) on);
		W16('P', (uint16_t ) protection == GPIO_PIN_SET ? 0 : 1);
		W16('T', ADC_TEMP);
		W16('I', vref);

		W16('B', ADC_VB);
		W16('C', ADC_CURRENT);
		W16('V', ADC_VOUT);
		W16('A', ADC_AC_UV);
		W16('c', s_current_pwm_percent);
		W16('v', s_voltage_pwm_percent);

		if (mode != POWER_MODE) {
			W16('M', (uint16_t ) mode);
			W16('S', charger.stage);
			W16('D', charger.done);
		}

		buff[i++] = '\r';
		buff[i++] = '\n';

		HAL_UART_Transmit(&huart1, (const uint8_t*) buff, i, 500);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = ENABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = ENABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_VREFINT;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 3999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 3999;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.Pulse = 2000;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ON_Pin|RELAY_Pin|FAN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PROTECTION_Pin */
  GPIO_InitStruct.Pin = PROTECTION_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PROTECTION_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PA6 PA7 PA11 PA12
                           PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_11|GPIO_PIN_12
                          |GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_GREEN_Pin */
  GPIO_InitStruct.Pin = LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_RED_Pin */
  GPIO_InitStruct.Pin = LED_RED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_RED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ON_Pin RELAY_Pin FAN_Pin */
  GPIO_InitStruct.Pin = ON_Pin|RELAY_Pin|FAN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
