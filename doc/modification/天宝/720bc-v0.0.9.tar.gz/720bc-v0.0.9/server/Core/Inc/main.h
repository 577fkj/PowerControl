/* USER CODE BEGIN Header */
/**
    750bc
    Copyright (C) 2023  bob pan

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define PROTECTION_Pin GPIO_PIN_0
#define PROTECTION_GPIO_Port GPIOF
#define PROTECTION_EXTI_IRQn EXTI0_1_IRQn
#define LED_GREEN_Pin GPIO_PIN_1
#define LED_GREEN_GPIO_Port GPIOB
#define PWM_CURRENT_Pin GPIO_PIN_8
#define PWM_CURRENT_GPIO_Port GPIOA
#define PWM_VOLTAGE_Pin GPIO_PIN_9
#define PWM_VOLTAGE_GPIO_Port GPIOA
#define LED_RED_Pin GPIO_PIN_10
#define LED_RED_GPIO_Port GPIOA
#define ON_Pin GPIO_PIN_3
#define ON_GPIO_Port GPIOB
#define RELAY_Pin GPIO_PIN_4
#define RELAY_GPIO_Port GPIOB
#define FAN_Pin GPIO_PIN_5
#define FAN_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

#define CHANNEL_PWM_CURRENT TIM_CHANNEL_1
#define CHANNEL_PWM_VOLTAGE TIM_CHANNEL_2

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
