
#!/bin/bash

set -ex

/opt/stm32cubeide/plugins/com.st.stm32cube.ide.mcu.externaltools.jlink.linux64_2.1.200.202301161003/tools/bin/JLinkExe  -device STM32F042K6 -speed 4000 -if swd -autoconnect 1 -commandfile f.jlink

